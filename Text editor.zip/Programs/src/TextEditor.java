import java.io.*;

public class TextEditor {

    static TextEditor textEditor = new TextEditor();
    static PageLinkedList pages = new PageLinkedList();
    static PNode currentPage = new PNode();
    static UndoStack undoStack = new UndoStack();
    static RedoStack redoStack = new RedoStack();
    boolean undone = false;

    public void test (){
        currentPage = pages.first;
        textEditor.nextPage();
        textEditor.nextPage();
        textEditor.previousPage();
        System.out.println("Test of where and lines methods : ");
        System.out.println("We are currently on page " + textEditor.where() + ".");
        System.out.println("Page " + textEditor.where() + " has " + textEditor.lines() + " lines.");
        System.out.println("\nTest of append ,undo, redo and show methods : ");
        textEditor.append("the United States (Barbosa, 2016). At times, I want to techno-fast and turn off, find\nzen, sign out.");
        textEditor.show(textEditor.lines());
        System.out.println("\nif undone :");
        textEditor.undo();
        textEditor.show(textEditor.lines());
        System.out.println("\nif redone : ");
        textEditor.redo();
        textEditor.show(textEditor.lines());
        System.out.println("\nTest of insert method : ");
        textEditor.insert("on me to fix the problem. At times, the array of apps can be distracting when I am", 4);
        textEditor.show(textEditor.lines());
        System.out.println("\nTest of remove method : ");
        textEditor.remove(8);
        textEditor.show(textEditor.lines());
        System.out.println("\nTest of replace method : ");
        textEditor.replace(10, "by workers who make under two dollars an hour with components shipped from");
        textEditor.show(textEditor.lines());
        textEditor.nextPage();
        System.out.println("\nTest of swap method : ");
        textEditor.swap(2,3);
        textEditor.show(textEditor.lines());
        System.out.println("\nTest of find method : ");
        textEditor.find("describe");
        System.out.println("\nTest of find and replace method : ");
        textEditor.findAndReplace("mobile", "smartphone");
    }

    public void parse (String address) throws IOException{
        int i, j = 0;
        InputStream file = new FileInputStream(address);
        DataInputStream reader = new DataInputStream(file);
        while (reader.available() != 0){
            i = 0;
            LineLinkedList lines = new LineLinkedList();
            String s = reader.readLine();
            while (!s.equals("$")){
                lines.addLNode(s,i);
                i++;
                if (reader.available() != 0){
                    s = reader.readLine();
                } else {
                    break;
                }
            }
            pages.addPNode(lines,j,i);
            j++;
        }
    }

    public void save (String address) throws IOException {
        OutputStream file = new FileOutputStream(address);
        DataOutputStream writer = new DataOutputStream(file);
        PNode p;
        p = pages.first;
        while(p != null) {
            LNode l;
            l = p.info.first;
            while(l != null) {
                writer.writeBytes(l.info + "\n");
                l = l.next;
            }
            if (p.next != null){
                writer.writeBytes("$" + "\n");
            }
            p = p.next;
        }
    }

    public int where (){
        return currentPage.pageNumber + 1;
    }

    public void nextPage (){
        if (currentPage.next != null){
            currentPage = currentPage.next;
        }
    }

    public void previousPage (){
        if (currentPage.prev != null){
            currentPage = currentPage.prev;
        }
    }

    public int lines (){
        return currentPage.linesCount;
    }

    public void show (int n){
        LNode p = currentPage.info.first;
        while(p != null && p.lineNumber != n) {
            System.out.println(p.info);
            p = p.next;
        }
    }

    public void append (String s){
        int cnt = 0, index = 0;
        char[] s1 = s.toCharArray();
        for (int i = 0; i < s1.length; i++) {
            if (s1[i] == '\\' && s1[i + 1] == 'n'){
                String result = s.substring(index,i);
                currentPage.info.addLNode(result, currentPage.linesCount);
                currentPage.linesCount++;
                cnt++;
                index = i + 2;
            }
        }
        String result = s.substring(index, s1.length);
        currentPage.info.addLNode(result, currentPage.linesCount);
        currentPage.linesCount++;
        cnt++;
        undoStack.push(1,currentPage.linesCount - 1,cnt,"","");
    }

    public void insert (String s, int n){
        LNode p = new LNode();
        LNode q = currentPage.info.first;
        if (currentPage.linesCount <= n){
            p.info = s;
            p.lineNumber = currentPage.info.last.lineNumber;
            p.next = null;
            (currentPage.info.last).next = p;
            currentPage.info.last = p;
        } else {
            p.info = s;
            p.lineNumber = n - 1;
            p.prev = null;
            while (q.lineNumber != n - 1 && q.next != null){
                q = q.next;
            }
            p.next = q;
            if (q.lineNumber != 0){
                (q.prev).next = p;
                p.prev = q.prev;
            } else {
                currentPage.info.first = p;
            }
            q.prev = p;
            while (q != null){
                q.lineNumber = q.lineNumber + 1;
                q = q.next;
            }
        }
        if (!undone){
            undoStack.push(1,n,0,"","");
        } else {
            redoStack.push(1,n,0,"","");
        }
        currentPage.linesCount++;
    }

    public void remove (int n){
        LNode p = getLNode(n);
        currentPage.info.removeLNode(p);
        if (!undone){
            undoStack.push(0,n,0,p.info,"");
        } else {
            redoStack.push(0,n,0,p.info,"");
        }
        currentPage.linesCount--;
    }

    public void replace (int n, String s){
        LNode p = getLNode(n);
        if (!undone){
            undoStack.push(2,n,0,p.info,"");
        } else {
            redoStack.push(2,n,0,p.info,"");
        }
        p.info = s;
    }

    public void swap (int n, int m){
        String s1, s2;
        LNode p1 = getLNode(n);
        LNode p2 = getLNode(m);
        if (p1 != null && p2 != null){
            s1 = p1.info;
            s2 = p2.info;
            p1.info = s2;
            p2.info = s1;
            if (!undone){
                undoStack.push(3,m,n,"","");
            } else {
                redoStack.push(3,m,n,"","");
            }
        }
    }

    public void find (String s){
        PNode p = pages.first;
        LNode l = p.info.first;
        while (p.next != null){
            while (l != null){
                if (l.info.contains(s)){
                    System.out.println("This string founded on page " + (p.pageNumber + 1) + " and line " + (l.lineNumber + 1) + ".");
                    System.out.println("The line containing the string : " + l.info);
                }
                l = l.next;
            }
            p = p.next;
            l = p.info.first;
        }
    }

    public void findAndReplace (String s, String t){
        PNode p = pages.first;
        LNode l = p.info.first;
        System.out.println("The new lines will be : ");
        while (p.next != null){
            while (l != null){
                if (l.info.contains(s)){
                    l.info = l.info.replaceAll(s,t);
                    System.out.println(l.info);
                }
                l = l.next;
            }
            p = p.next;
            l = p.info.first;
        }
        if (!undone){
            undoStack.push(4,0,0,t,s);
        } else {
            redoStack.push(4,0,0,t,s);
        }
    }

    public void undo (){
        undone = true;
        undoStack.pop();
        undone = false;
    }

    public void redo (){
        redoStack.pop();
    }

    public LNode getLNode (int n){
        LNode p = currentPage.info.first;
        while (p.lineNumber != n - 1){
            p = p.next;
            if (p == null){
                return null;
            }
        }
        return p;
    }

    public static void main(String[] args) throws IOException {
        textEditor.parse("text.txt");
        textEditor.test();
        textEditor.save("final text.txt");
    }
}

class PageLinkedList {

    PNode first;

    public PageLinkedList() {
        first = null;
    }
    boolean isEmpty() {
        return first == null;
    }
    void addPNode(LineLinkedList list, int n, int linesCount) {
        PNode p, q;
        p = new PNode();
        p.info = list;
        p.pageNumber = n;
        p.linesCount = linesCount;
        p.next = null;
        if (isEmpty()) {
            first = p;
            p.prev = null;
        } else {
            q = first;
            while (q.next != null){
                q = q.next;
            }
            q.next = p;
            p.prev = q;
        }
    }
}

class PNode {
    LineLinkedList info;
    int pageNumber;
    int linesCount;
    PNode next;
    PNode prev;
}

class LineLinkedList {

    LNode first, last;

    public LineLinkedList (){
        first = null;
    }
    boolean isEmpty (){
        return first == null;
    }
    void addLNode (String s, int n){
        LNode p, q;
        p = new LNode();
        p.info = s;
        p.lineNumber = n;
        p.next = null;
        if (isEmpty()){
            first = p;
            p.prev = null;
        } else {
            q = first;
            while (q.next != null){
                q = q.next;
            }
            q.next = p;
            p.prev = q;
        }
        last = p;
    }
    void removeLNode (LNode p){
        LNode q = p;
        if (p.lineNumber == 0){
            (p.next).prev = null;
            TextEditor.currentPage.info.first = p.next;
        } else if (p.lineNumber == TextEditor.currentPage.linesCount - 1){
            (p.prev).next = p.next;
            TextEditor.currentPage.info.last = p.prev;
        } else {
            (p.prev).next = p.next;
            (p.next).prev = p.prev;
        }
        while (q.next != null){
            q.lineNumber = q.lineNumber - 1;
            q = q.next;
        }
    }
}

class LNode {
    String info;
    int lineNumber;
    LNode next;
    LNode prev;
}

class UndoStack {

    Information top;

    public UndoStack() {
        top = null;
    }

    boolean isEmpty (){
        return top == null;
    }

    void push (int operationNumber, int lineNumber, int lineNumberTarget, String lineInfo, String lineInfoTarget){
        Information p = new Information(operationNumber,lineNumber,lineNumberTarget,lineInfo,lineInfoTarget);
        p.next = null;
        if (!isEmpty()) {
            p.next = top;
        }
        top = p;
    }

    void pop (){
        Information p = top;
        if (!isEmpty()){
            switch (p.operationNumber){
                case 0:
                    TextEditor.textEditor.insert(p.lineInfo,p.lineNumber);
                    break;
                case 1:
                    if (p.lineNumberTarget == 0){
                        TextEditor.textEditor.remove(p.lineNumber  +1);
                    } else {
                        for (int i = 0; i < p.lineNumberTarget; i++) {
                            TextEditor.textEditor.remove(p.lineNumber + 1);
                            p.lineNumber--;
                        }
                    }
                    break;
                case 2:
                    TextEditor.textEditor.replace(p.lineNumber,p.lineInfo);
                    break;
                case 3:
                    TextEditor.textEditor.swap(p.lineNumber,p.lineNumberTarget);
                    break;
                case 4:
                    TextEditor.textEditor.findAndReplace(p.lineInfo,p.lineInfoTarget);
                    break;
            }
            top = top.next;
        }
    }
}

class RedoStack {

    Information top;

    public RedoStack() {
        top = null;
    }

    boolean isEmpty (){
        return top == null;
    }

    void push (int operationNumber, int lineNumber, int lineNumberTarget, String lineInfo, String lineInfoTarget){
        Information p = new Information(operationNumber,lineNumber,lineNumberTarget,lineInfo,lineInfoTarget);
        p.next = null;
        if (!isEmpty()) {
            p.next = top;
        }
        top = p;
    }

    void pop (){
        Information p = top;
        if (!isEmpty()){
            switch (p.operationNumber){
                case 0:
                    TextEditor.textEditor.insert(p.lineInfo,p.lineNumber);
                    break;
                case 1:
                    TextEditor.textEditor.remove(p.lineNumber);
                    break;
                case 2:
                    TextEditor.textEditor.replace(p.lineNumber,p.lineInfo);
                    break;
                case 3:
                    TextEditor.textEditor.swap(p.lineNumber,p.lineNumberTarget);
                    break;
                case 4:
                    TextEditor.textEditor.findAndReplace(p.lineInfo,p.lineInfoTarget);
                    break;
            }
            top = top.next;
        }
    }
}

class Information {
    public Information(int operationNumber, int lineNumber, int lineNumberTarget, String lineInfo, String lineInfoTarget) {
        this.operationNumber = operationNumber;
        this.lineNumber = lineNumber;
        this.lineNumberTarget = lineNumberTarget;
        this.lineInfo = lineInfo;
        this.lineInfoTarget = lineInfoTarget;
    }

    int operationNumber;
    int lineNumber, lineNumberTarget;
    String lineInfo, lineInfoTarget;
    Information next;
}